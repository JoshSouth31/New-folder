using UnityEngine;
[System.Serializable]
public class ItemData
{
    public string itemName;
    public int price;
    public string description;
    public Sprite itemIcon;
}